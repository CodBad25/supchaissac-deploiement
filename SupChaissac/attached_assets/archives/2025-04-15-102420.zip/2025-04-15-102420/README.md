# Sauvegarde du 2025-04-15-102429
## Fonctionnalités incluses
- Interface administrateur simplifiée
- Séparation claire des rôles (admin/principal)
- Interface de validation des séances améliorée pour le principal
- Authentification et gestion des utilisateurs
- Interface enseignant avec saisie des séances
